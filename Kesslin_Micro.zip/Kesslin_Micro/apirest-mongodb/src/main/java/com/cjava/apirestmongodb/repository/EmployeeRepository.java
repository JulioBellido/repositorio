package com.cjava.apirestmongodb.repository;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.cjava.apirestmongodb.model.Employee;

public interface EmployeeRepository extends MongoRepository<Employee, String> {
}
