package com.cjava.apirestmongodb.controller;
/*
 * Aplicativo desarrollado para la clase de Java Expert
 * Autor: CJavaPeru
 * Version 0.002
 * www.cjavaperu.com
 */
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.cjava.apirestmongodb.model.Employee;
import com.cjava.apirestmongodb.repository.EmployeeRepository;

@RestController
public class EmployeeController
{
	@Autowired
	EmployeeRepository employeeRepository;

	@GetMapping(value = "/healthcheck", produces = "application/json; charset=utf-8")
	public String getHealthCheck()
	{
		return "{ \"todoOk\" : true }";
	}

	@GetMapping("/employees")
	public List<Employee> getEmployees()
	{
		List<Employee> employeesList = employeeRepository.findAll();
		return employeesList;
	}

	@GetMapping("/employee/{id}")
	public Optional<Employee> getEmployee(@PathVariable String id)
	{
		Optional<Employee> emp = employeeRepository.findById(id);
		return emp;
	}

	@PutMapping("/employee/{id}")
	public Optional<Employee> updateEmployee(@RequestBody Employee newEmployee, @PathVariable String id)
	{
		Optional<Employee> optionalEmp = employeeRepository.findById(id);
		if (optionalEmp.isPresent()) {
			Employee emp = optionalEmp.get();
			emp.setNombre(newEmployee.getNombre());
			emp.setApellido(newEmployee.getApellido());
			//emp.setEmail(newEmployee.getEmail());
			emp.setDistrito(newEmployee.getDistrito());
			emp.setDNI(newEmployee.getDNI());
			emp.setedad(newEmployee.getedad());
			employeeRepository.save(emp);
		}
		return optionalEmp;
	}

	@DeleteMapping(value = "/employee/{id}", produces = "application/json; charset=utf-8")
	public String deleteEmployee(@PathVariable String id) {
		Boolean result = employeeRepository.existsById(id);
		employeeRepository.deleteById(id);
		return "{ \"operacionExitosa\" : "+ (result ? "true" : "false") +" }";
	}

	@PostMapping("/employee")
	public Employee addEmployee(@RequestBody Employee newEmployee)
	{
		Employee emp = new Employee(newEmployee.getId(), newEmployee.getNombre(), newEmployee.getApellido(),newEmployee.getDistrito(),newEmployee.getDNI(),newEmployee.getedad()); //newEmployee.getEmail());
		employeeRepository.insert(emp);
		return emp;
	}
}
