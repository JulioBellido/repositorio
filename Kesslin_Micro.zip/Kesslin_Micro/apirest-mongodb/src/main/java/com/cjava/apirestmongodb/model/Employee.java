package com.cjava.apirestmongodb.model;
/*
 * Aplicativo desarrollado para la clase de Java Expert
 * Autor: CJavaPeru
 * Version 0.002
 * www.cjavaperu.com
 */
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "alumno")

public class Employee {
	
	@Id //tiene id mongo ya no le va poner
	private String id;
	private String Nombre;
	private String Apellido;
	//private String email;
	private String Distrito;
	private String DNI;
	private String edad;
	
	
	public Employee(String id, String Nombre, String Apellido,String Distrito,String DNI,String edad) {
		super();
		this.id = id;
		this.Nombre = Nombre;
		this.Apellido = Apellido;
		this.Distrito = Distrito;
		this.DNI = DNI;
		this.edad = edad;
	
	}
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String Nombre) {
		this.Nombre = Nombre;
	}
	public String getApellido() {
		return Apellido;
	}
	public void setApellido(String Apellido) {
		this.Apellido = Apellido;
	}
	//public String getEmail() {
	//	return email;
	//}
	//public void setEmail(String email) {
	//	this.email = email;
	//}

	public String getDistrito() {
		return Distrito;
	}

	public void setDistrito(String Distrito) {
		this.Distrito = Distrito;
	}

	public String getedad() {
		return edad;
	}


	public void setedad(String edad) {
		this.edad = edad;
	}


	public String getDNI() {
		return DNI;
	}


	public void setDNI(String DNI) {
		this.DNI = DNI;
	}
}